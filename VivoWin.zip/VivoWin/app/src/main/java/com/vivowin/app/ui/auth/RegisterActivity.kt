package com.vivowin.app.ui.auth

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.vivowin.app.data.firebase.FirebaseRepository
import com.vivowin.app.databinding.ActivityRegisterBinding
import com.vivowin.app.util.DeviceUtils

class RegisterActivity : AppCompatActivity() {
    private lateinit var binding: ActivityRegisterBinding
    private val repo = FirebaseRepository()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnRegister.setOnClickListener {
            val name = binding.etName.text.toString().trim()
            var username = binding.etUsername.text.toString().trim()
            val email = binding.etEmail.text.toString().trim()
            val pass = binding.etPassword.text.toString().trim()
            val telegram = binding.etTelegram.text.toString().trim()
            val referCode = binding.etReferCode.text.toString().trim().ifEmpty { null }

            if (name.isEmpty() || email.isEmpty() || pass.isEmpty()) {
                Toast.makeText(this, "Fill required fields", Toast.LENGTH_SHORT).show(); return@setOnClickListener
            }
            if (username.isEmpty()) username = "vivowin" + (1000..9999).random()
            val deviceId = DeviceUtils.getDeviceId(this)

            repo.registerUser(name, username, email, pass, telegram, referCode, deviceId) { success, error ->
                if (success) { Toast.makeText(this, "Registered! Login now.", Toast.LENGTH_SHORT).show(); finish() }
                else Toast.makeText(this, error ?: "Failed", Toast.LENGTH_SHORT).show()
            }
        }
    }
}