package com.vivowin.app.ads

import android.app.Activity
import com.unity3d.ads.UnityAds
import com.unity3d.ads.UnityAdsShowOptions
import com.unity3d.ads.IUnityAdsShowListener
import com.unity3d.ads.UnityAds.UnityAdsShowCompletionState
import com.unity3d.ads.UnityAdsShowError

object UnityAdsManager {
    private const val REWARDED_ID = "Rewarded_Android" // replace if your placement id differs

    fun showRewarded(activity: Activity, onReward: () -> Unit, onFail: (String)->Unit) {
        if (!UnityAds.isReady(REWARDED_ID)) {
            onFail("Ad not ready")
            return
        }
        val listener = object : IUnityAdsShowListener {
            override fun onUnityAdsShowComplete(placementId: String?, state: UnityAdsShowCompletionState?) {
                if (state == UnityAdsShowCompletionState.COMPLETED) {
                    onReward()
                } else {
                    onFail("Ad not completed")
                }
            }

            override fun onUnityAdsShowFailure(placementId: String?, error: UnityAdsShowError?, message: String?) {
                onFail(message ?: "Show failed")
            }

            override fun onUnityAdsShowStart(placementId: String?) {}
            override fun onUnityAdsShowClick(placementId: String?) {}
        }
        UnityAds.show(activity, REWARDED_ID, UnityAdsShowOptions(), listener)
    }
}