package com.vivowin.app.ui.profile

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.vivowin.app.data.firebase.FirebaseRepository
import com.vivowin.app.databinding.ActivityProfileBinding

class ProfileActivity : AppCompatActivity() {
    private lateinit var binding: ActivityProfileBinding
    private val repo = FirebaseRepository()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProfileBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val uid = repo.currentUserId()
        if (uid == null) { Toast.makeText(this, "Not logged in", Toast.LENGTH_SHORT).show(); finish(); return }
        repo.getUser(uid) { user ->
            if (user == null) { Toast.makeText(this, "User not found", Toast.LENGTH_SHORT).show(); finish(); return@getUser }
            binding.tvName.text = "Name: ${user.name}"
            binding.tvUsername.text = "Username: ${user.username}"
            binding.tvEmail.text = "Email: ${user.email}"
            binding.tvUserId.text = "User ID: ${user.userId}"
            binding.tvReferCode.text = "Your refer code: ${user.referCode}"
            binding.tvJoinDate.text = "Joined: ${user.joinDate}"
        }
    }
}