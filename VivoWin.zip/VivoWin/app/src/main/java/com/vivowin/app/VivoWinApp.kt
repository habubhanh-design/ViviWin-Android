package com.vivowin.app

import android.app.Application
import com.unity3d.ads.UnityAds

class VivoWinApp : Application() {
    override fun onCreate() {
        super.onCreate()
        val gameId = "5971267" // provided by you
        val testMode = true
        UnityAds.initialize(this, gameId, testMode)
    }
}