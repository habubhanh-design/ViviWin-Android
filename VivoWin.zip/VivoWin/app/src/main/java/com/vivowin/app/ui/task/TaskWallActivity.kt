package com.vivowin.app.ui.task

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.firebase.auth.FirebaseAuth
import com.vivowin.app.ads.UnityAdsManager
import com.vivowin.app.data.firebase.FirebaseRepository
import com.vivowin.app.data.model.Task
import com.vivowin.app.databinding.ActivityTaskWallBinding

class TaskWallActivity : AppCompatActivity() {
    private lateinit var binding: ActivityTaskWallBinding
    private val repo = FirebaseRepository()
    private val uid = FirebaseAuth.getInstance().currentUser?.uid

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTaskWallBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.rvTasks.layoutManager = LinearLayoutManager(this)
        repo.getTasks { tasks ->
            binding.rvTasks.adapter = TaskAdapter(tasks) { task -> handleTask(task) }
        }
    }

    private fun handleTask(task: Task) {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(task.link))) }
        catch (e: Exception) { Toast.makeText(this, "Invalid Link", Toast.LENGTH_SHORT).show(); return }

        UnityAdsManager.showRewarded(this, onReward = {
            uid?.let {
                repo.updateUserBalanceWithBonus(it, task.reward, false) { success ->
                    Toast.makeText(this, if (success) "Reward added!" else "Failed", Toast.LENGTH_SHORT).show()
                }
            }
        }, onFail = { Toast.makeText(this, it, Toast.LENGTH_SHORT).show() })
    }
}