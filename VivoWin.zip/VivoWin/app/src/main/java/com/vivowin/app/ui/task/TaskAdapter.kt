package com.vivowin.app.ui.task

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.vivowin.app.data.model.Task
import com.vivowin.app.databinding.ItemTaskBinding

class TaskAdapter(private val list: List<Task>, private val onClick: (Task)->Unit) : RecyclerView.Adapter<TaskAdapter.ViewHolder>() {
    inner class ViewHolder(val binding: ItemTaskBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(task: Task) {
            binding.tvTitle.text = task.title
            binding.tvDesc.text = task.description
            binding.tvReward.text = "Reward: ₹${task.reward}"
            binding.btnClaim.setOnClickListener { onClick(task) }
        }
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = ViewHolder(ItemTaskBinding.inflate(LayoutInflater.from(parent.context), parent, false))
    override fun getItemCount() = list.size
    override fun onBindViewHolder(holder: ViewHolder, position: Int) = holder.bind(list[position])
}