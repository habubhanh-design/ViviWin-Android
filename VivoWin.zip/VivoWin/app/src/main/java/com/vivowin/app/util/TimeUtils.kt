package com.vivowin.app.util

object TimeUtils {
    fun canClaimDailyBonus(lastClaim: Long?): Boolean {
        val cooldownMillis = 2 * 60 * 1000L
        val now = System.currentTimeMillis()
        return lastClaim == null || now - lastClaim >= cooldownMillis
    }
}