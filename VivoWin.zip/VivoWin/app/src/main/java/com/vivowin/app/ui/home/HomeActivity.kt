package com.vivowin.app.ui.home

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.vivowin.app.ads.UnityAdsManager
import com.vivowin.app.data.firebase.FirebaseRepository
import com.vivowin.app.data.model.User
import com.vivowin.app.databinding.ActivityHomeBinding
import com.vivowin.app.ui.auth.LoginActivity
import com.vivowin.app.ui.leaderboard.LeaderboardActivity
import com.vivowin.app.ui.profile.ProfileActivity
import com.vivowin.app.ui.task.TaskWallActivity
import com.vivowin.app.ui.wallet.WalletActivity
import com.vivowin.app.util.TimeUtils

class HomeActivity : AppCompatActivity() {
    private lateinit var binding: ActivityHomeBinding
    private val repo = FirebaseRepository()
    private var currentUser: User? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (FirebaseAuth.getInstance().currentUser == null) {
            startActivity(Intent(this, LoginActivity::class.java)); finish(); return
        }
        binding = ActivityHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        loadUser()
        observeOnline()

        binding.btnProfile.setOnClickListener { startActivity(Intent(this, ProfileActivity::class.java)) }
        binding.btnTaskWall.setOnClickListener { startActivity(Intent(this, TaskWallActivity::class.java)) }
        binding.btnLeaderboard.setOnClickListener { startActivity(Intent(this, LeaderboardActivity::class.java)) }
        binding.btnWallet.setOnClickListener { startActivity(Intent(this, WalletActivity::class.java)) }

        binding.btnLogout.setOnClickListener {
            repo.logout()
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }

        binding.btnDailyBonus.setOnClickListener {
            val u = currentUser
            if (u == null) { Toast.makeText(this, "Please wait...", Toast.LENGTH_SHORT).show(); return@setOnClickListener }
            if (!TimeUtils.canClaimDailyBonus(u.lastDailyBonusAt)) { Toast.makeText(this, "2 minute baad aana", Toast.LENGTH_SHORT).show(); return@setOnClickListener }
            UnityAdsManager.showRewarded(this, onReward = {
                val uid = repo.currentUserId() ?: return@showRewarded
                repo.updateUserBalanceWithBonus(uid, 5, true) { success ->
                    if (success) { Toast.makeText(this, "Daily bonus +₹5", Toast.LENGTH_SHORT).show(); loadUser() }
                    else Toast.makeText(this, "Update failed", Toast.LENGTH_SHORT).show()
                }
            }, onFail = { Toast.makeText(this, it, Toast.LENGTH_SHORT).show() })
        }
    }

    private fun loadUser() {
        val uid = repo.currentUserId() ?: return
        repo.getUser(uid) { user ->
            if (user == null) { Toast.makeText(this, "User not found", Toast.LENGTH_SHORT).show(); return@getUser }
            currentUser = user
            binding.tvWelcome.text = "Welcome, ${user.name}"
            binding.tvBalance.text = "Balance: ₹${user.balance}"
        }
    }

    private fun observeOnline() {
        repo.observeOnlineCount { count -> binding.tvOnlineUsers.text = "Online users: $count" }
    }
}