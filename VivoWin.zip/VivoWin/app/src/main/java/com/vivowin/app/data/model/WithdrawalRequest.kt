package com.vivowin.app.data.model

data class WithdrawalRequest(
    val id: String = "",
    val userId: String = "",
    val amount: Int = 0,
    val upi: String = "",
    val createdAt: Long = 0L,
    val status: String = "pending"
)