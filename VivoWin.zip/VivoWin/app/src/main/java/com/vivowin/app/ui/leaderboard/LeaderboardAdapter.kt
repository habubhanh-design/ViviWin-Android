package com.vivowin.app.ui.leaderboard

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.vivowin.app.data.model.User
import com.vivowin.app.databinding.LeaderboardItemBinding

class LeaderboardAdapter(private val list: List<User>) : RecyclerView.Adapter<LeaderboardAdapter.ViewHolder>() {
    inner class ViewHolder(val binding: LeaderboardItemBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(user: User, pos: Int) {
            binding.tvRank.text = "${pos+1}."
            binding.tvName.text = user.username
            binding.tvBalance.text = "₹${user.balance}"
        }
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = ViewHolder(LeaderboardItemBinding.inflate(LayoutInflater.from(parent.context), parent, false))
    override fun getItemCount() = list.size
    override fun onBindViewHolder(holder: ViewHolder, position: Int) = holder.bind(list[position], position)
}