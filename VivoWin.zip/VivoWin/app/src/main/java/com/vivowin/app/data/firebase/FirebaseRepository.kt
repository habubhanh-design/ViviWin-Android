package com.vivowin.app.data.firebase

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import com.vivowin.app.data.model.Task
import com.vivowin.app.data.model.User
import com.vivowin.app.data.model.WithdrawalRequest

class FirebaseRepository {
    private val auth = FirebaseAuth.getInstance()
    private val db = FirebaseDatabase.getInstance().reference

    fun currentUserId(): String? = auth.currentUser?.uid

    fun registerUser(
        name: String,
        username: String,
        email: String,
        password: String,
        telegramId: String,
        referCodeInput: String?,
        deviceId: String,
        onResult: (Boolean, String?) -> Unit
    ) {
        auth.createUserWithEmailAndPassword(email, password)
            .addOnCompleteListener { t ->
                if (!t.isSuccessful) { onResult(false, t.exception?.message); return@addOnCompleteListener }
                val uid = auth.currentUser!!.uid
                val userRefCode = (100000..999999).random().toString()
                val joinedVia = if (referCodeInput.isNullOrBlank()) null else referCodeInput
                val user = User(
                    userId = uid,
                    name = name,
                    username = username,
                    email = email,
                    telegramId = telegramId,
                    deviceId = deviceId,
                    referCode = userRefCode,
                    joinedVia = joinedVia,
                    joinDate = java.time.LocalDate.now().toString(),
                    balance = 10,
                    online = true
                )
                db.child("users").child(uid).setValue(user).addOnCompleteListener { save ->
                    if (save.isSuccessful) {
                        db.child("online_users").child(uid).setValue(true)
                        onResult(true, null)
                    } else onResult(false, save.exception?.message)
                }
            }
    }

    fun loginUser(email: String, password: String, onResult: (Boolean, String?) -> Unit) {
        auth.signInWithEmailAndPassword(email, password)
            .addOnCompleteListener { t ->
                if (!t.isSuccessful) { onResult(false, t.exception?.message); return@addOnCompleteListener }
                val uid = auth.currentUser!!.uid
                db.child("users").child(uid).child("online").setValue(true)
                db.child("online_users").child(uid).setValue(true)
                onResult(true, null)
            }
    }

    fun logout() {
        val uid = currentUserId()
        if (uid != null) {
            db.child("users").child(uid).child("online").setValue(false)
            db.child("online_users").child(uid).removeValue()
        }
        auth.signOut()
    }

    fun getUser(uid: String, listener: (User?) -> Unit) {
        db.child("users").child(uid).addListenerForSingleValueEvent(object: ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) { listener(snapshot.getValue(User::class.java)) }
            override fun onCancelled(error: DatabaseError) { listener(null) }
        })
    }

    fun observeOnlineCount(listener: (Long) -> Unit) {
        db.child("online_users").addValueEventListener(object: ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) { listener(snapshot.childrenCount) }
            override fun onCancelled(error: DatabaseError) {}
        })
    }

    fun updateUserBalanceWithBonus(uid: String, bonus: Int, updateLastBonusAt: Boolean, onDone: (Boolean) -> Unit) {
        val ref = db.child("users").child(uid)
        ref.runTransaction(object: Transaction.Handler {
            override fun doTransaction(currentData: MutableData): Transaction.Result {
                val user = currentData.getValue(User::class.java) ?: return Transaction.success(currentData)
                val newBal = user.balance + bonus
                val updated = user.copy(
                    balance = newBal,
                    lastDailyBonusAt = if (updateLastBonusAt) System.currentTimeMillis() else user.lastDailyBonusAt
                )
                currentData.value = updated
                return Transaction.success(currentData)
            }
            override fun onComplete(error: DatabaseError?, committed: Boolean, snapshot: DataSnapshot?) {
                onDone(error == null && committed)
            }
        })
    }

    fun getTasks(listener: (List<Task>) -> Unit) {
        db.child("tasks").orderByChild("active").equalTo(true)
            .addListenerForSingleValueEvent(object: ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    val list = mutableListOf<Task>()
                    snapshot.children.forEach {
                        val t = it.getValue(Task::class.java)
                        if (t != null) list.add(t.copy(id = it.key ?: ""))
                    }
                    listener(list)
                }
                override fun onCancelled(error: DatabaseError) { listener(emptyList()) }
            })
    }

    fun getLeaderboard(listener: (List<User>) -> Unit) {
        db.child("users").addListenerForSingleValueEvent(object: ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val list = snapshot.children.mapNotNull { it.getValue(User::class.java) }.sortedByDescending { it.balance }
                listener(list)
            }
            override fun onCancelled(error: DatabaseError) { listener(emptyList()) }
        })
    }

    fun createWithdrawal(uid: String, amount: Int, upi: String, onDone: (Boolean, String?) -> Unit) {
        val reqId = db.child("withdrawals").child(uid).push().key ?: return
        val ref = db.child("withdrawals").child(uid).child(reqId)
        val r = WithdrawalRequest(id = reqId, userId = uid, amount = amount, upi = upi, createdAt = System.currentTimeMillis(), status = "pending")
        ref.setValue(r).addOnCompleteListener { onDone(it.isSuccessful, it.exception?.message) }
    }
}