package com.vivowin.app.data.model

data class Task(
    val id: String = "",
    val title: String = "",
    val description: String = "",
    val reward: Int = 0,
    val type: String = "",
    val link: String = "",
    val cooldownSeconds: Long = 300,
    val active: Boolean = true
)