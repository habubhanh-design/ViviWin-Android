package com.vivowin.app.ui.wallet

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.vivowin.app.data.firebase.FirebaseRepository
import com.vivowin.app.data.model.User
import com.vivowin.app.databinding.ActivityWalletBinding

class WalletActivity : AppCompatActivity() {
    private lateinit var binding: ActivityWalletBinding
    private val repo = FirebaseRepository()
    private var currentUser: User? = null
    private val minWithdraw = 250

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityWalletBinding.inflate(layoutInflater)
        setContentView(binding.root)
        loadUser()

        binding.btnWithdraw.setOnClickListener {
            val upi = binding.etUpi.text.toString().trim()
            val amount = binding.etAmount.text.toString().toIntOrNull()
            if (upi.isEmpty() || amount == null) { Toast.makeText(this, "Enter valid details", Toast.LENGTH_SHORT).show(); return@setOnClickListener }
            if (currentUser == null || currentUser!!.balance < minWithdraw) { Toast.makeText(this, "Min withdrawal is ₹$minWithdraw", Toast.LENGTH_SHORT).show(); return@setOnClickListener }
            val uid = FirebaseAuth.getInstance().currentUser?.uid ?: return@setOnClickListener
            repo.createWithdrawal(uid, amount, upi) { success, error ->
                if (success) Toast.makeText(this, "Request submitted!", Toast.LENGTH_SHORT).show() else Toast.makeText(this, error ?: "Failed", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun loadUser() {
        val uid = FirebaseAuth.getInstance().currentUser?.uid ?: return
        repo.getUser(uid) {
            if (it != null) {
                currentUser = it
                binding.tvBalance.text = "Balance: ₹${it.balance}"
            }
        }
    }
}