package com.vivowin.app.data.model

data class User(
    val userId: String = "",
    val name: String = "",
    val username: String = "",
    val email: String = "",
    val telegramId: String = "",
    val deviceId: String = "",
    val referCode: String = "",
    val joinedVia: String? = null,
    val joinDate: String = "",
    val balance: Int = 0,
    val online: Boolean = false,
    val lastDailyBonusAt: Long? = null,
    val banned: Boolean = false
)